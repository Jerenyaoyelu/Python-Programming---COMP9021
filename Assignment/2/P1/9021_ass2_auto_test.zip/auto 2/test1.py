import os
os.system("echo '0\nRicky\n100\n' | python3 maze_generator.py")
