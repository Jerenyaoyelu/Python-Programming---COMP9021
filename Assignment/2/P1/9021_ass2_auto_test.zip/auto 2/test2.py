import os
os.system("echo '5\nRicky1\n100\n' | python3 maze_generator.py")